Virtua Racing - Xbox Series Consoles and PC.
Virtua Racing - Xbox 360 v1.0.2

As always you MUST PROVIDE YOUR OWN "vr.zip" I can not include the Virtua Racing rom

Installation
PC and Xbox360 - Make sure vr.zip is in the roms folder and start vr.exe or default.xex
Xbox Series Consoles - Install the appx via dev portal, place vr.zip on the root of a usb device and then start Virtua Racing on the console. The rom will be copied to the consoles internal storage and be used from there.

Some features such as video options and wheel configuration do not apply to the xbox 360 build. These remain unchanged from 1.0.1
The main upgrade adds cross platform play via system link and online play.

Online Requirements
For PC, make sure vr.exe is allowed through your firewall.
For all platforms, you must create a name in the Multiplayer menu before searching for or hosting a lobby.
You can change this name between sessions if you like; it's only used as an ID in the Server Browser and Lobby menus.
Online and System Link are provided "as-is" and are very much an experimental feature.
Please keep in mind this is homebrew; I do not have the infrastructure of a large provider.
For NAT traversal, I use two nodes, one in the EU and one in the US. If the host is in the US, the US relay will automatically be used.


When hosting, you set the difficulty and the Race Mode (Normal or GP), then the lobby is created and listed in the browser.
Once in a lobby, left and right select the car color, and A readies up.
The Virtua Racing rom will load once all guests have readied up and the host readies up.
The host is able to start the game as soon as at least 1 other player has joined and is ready.
Please note: Due to differences in load times, for best results, once the ROM has initially loaded, let the attract mode play and confirm link status with the correct player count.

Wheel Users
Plug in your wheel, head to the Controller Options, and ensure your wheel is detected.
Switch from Controller to Wheel.
Navigate to Wheel Button Setup. Follow the on-screen prompts to bind your wheel's face buttons to the corresponding controller buttons.
Adjust steering angle and FFB strength to suit.

Video Options
Toggle for 16:9 or 4:3
Brightness slider
CRT filters
Resolution scale slider
Smooth and Smooth+ - These fake a 60 FPS polygon renderer. They aim to smooth out the original 30 FPS polygon scene. MAY CAUSE ARTIFACTING!
Fade - Pop-up fader. This aims to reduce the jarring pop-in by fading objects in instead.

Controller Options
Rebind controller buttons
Rumble toggle
Rumble strength
Controller - Wheel toggle
Wheel key setup for menu and in-game use
Force feedback strength slider

Solo Play
Language - English or Japanese
Difficulty toggle

Multiplayer
Online up to 8 players
System Link up to 8 players